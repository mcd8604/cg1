void drawLine(int x0, int y0, int x1, int y1);
void drawPolygon(int n, int x[], int y[]);
void clipPolygon(int in, int inx[], int iny[], int *out, int outx[], int outy[], int x0, int y0, int x1, int y1);
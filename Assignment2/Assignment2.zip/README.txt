Platform on which you tested your implementation: 
	
	Windows XP, Visual Studio 2008



Instructions for building and running:

	Open Assignment2.sln, Build and run using Visual Studio 2008.

	In order to build each test, you will need to include only one of each of the following files at any one time:
		-lineTest.cpp
		-fillTest.cpp
		-clipTest.cpp
		-paint.cpp

	I included executable assemblies for the lineTest, fillTest, and clipTest in the root folder of the solution as well.

	*Each file is an entry point, so be sure that only one of them is included and the others are not. To exclude a file, right click the file name in the Solution Explorer and select "Exclude From Project". To include a file, right click it in the Solution Explorer and select "Include In Project."

	**Sorry for the inconvenience, I could not get library referencing to work properly with multiple projects.
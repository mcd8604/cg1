Author: Mike DeMauro
Platform: Windows
Language: C++

Compiling and running through Visual Studio:

-Open Assignments.sln in Visual Studio 2008. Build the 2DDrawing project (SHIFT+F6). 

-Start the project to run (F5). Or open Release/2DDrawing.exe

-The Game Design Lab, Room 2000, has Visual Studio 2008 installed.

Resources:

-I found the following sites extremely useful:

http://www.glprogramming.com/blue/
http://www.opengl.org/documentation/specs/glut/spec3/spec3.html

How To Use:

-Left Click the mouse on the screen to create points.

-Right click the mouse on the screen to pull up the menu.

-From the menu, choose different draw modes or change screens.